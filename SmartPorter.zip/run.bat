@echo off
title Smart Porter - Luggage Management System
echo ==================================================================
echo   Starting Smart Porter Server (Rapido/Uber for Railway Stations)
echo ==================================================================

REM Compile Java files into bin directory
echo Compiling source code...
if not exist "bin" mkdir bin
javac -d bin -cp "bin;lib/*" src\main\java\com\smartporter\config\*.java src\main\java\com\smartporter\database\*.java src\main\java\com\smartporter\model\*.java src\main\java\com\smartporter\dao\*.java src\main\java\com\smartporter\service\*.java src\main\java\com\smartporter\util\*.java src\main\java\com\smartporter\*.java

if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Compilation failed. Please ensure JDK 17+ is installed and in your PATH.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo Starting Smart Porter HTTP Application Server on port 8080...
echo Open your web browser at: http://localhost:8080/SmartPorter/
echo (Press Ctrl+C to stop the server)
echo ==================================================================
java -cp "bin;lib/*" com.smartporter.ServerRunner
pause
